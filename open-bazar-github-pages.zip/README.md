# Open Bazar
Online marketplace for Nepal (PWA: HTML/JS + Firebase).

## GitHub Pages
1. New PUBLIC repository (e.g. `open-bazar`); upload ALL files to the repo root.
2. Settings -> Pages -> Deploy from a branch -> main / (root).
3. Firebase -> Authentication -> Settings -> Authorized domains -> add `YOUR-USERNAME.github.io`.
4. Firebase -> Firestore -> Rules -> paste `firestore.rules` -> Publish.
5. Log in once with the owner Gmail first (admin).
6. AI: Firebase -> Build -> AI Logic -> Gemini Developer API (no billing).
